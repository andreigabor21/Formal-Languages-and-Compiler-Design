from UI import UI

if __name__ == "__main__":
    ui = UI()
    ui.run()